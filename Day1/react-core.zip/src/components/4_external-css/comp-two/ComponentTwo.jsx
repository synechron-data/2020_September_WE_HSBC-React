import React, { Component } from 'react';

import './ComponentTwo.css';

class ComponentTwo extends Component {
    render() {
        return (
            <h2 className="card2 text-success">Hello from Component Two</h2>
        );
    }
}

export default ComponentTwo;