import React, { Component } from 'react';

class ComponentWithState extends Component {
    constructor() {
        super();

        // State can only be initialized in the constructor
        // State must be set to an object or null
        // this.state = "Synechron";

        this.state = { name: "Synechron" };

        console.log('Ctor, State: ', this.state);
    }

    render() {
        console.log('Render, State: ', this.state);
        return (
            <h2 className="text-info">Hello, {this.state.name}</h2>
        );
    }
}

export default ComponentWithState;