// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return "Hello";
//         // return 1000;
//         // return true;
//         // return Symbol("Hello");
//         // return undefined;       // Nothing was returned from render. 
//         // return null;
//         // return { id: 1 };    // Objects are not valid as a React child
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------
// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------
// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------
// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </div>
//         );
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------
// import React, { Component, Fragment } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             // <React.Fragment>
//             //     <h1 className="abc">Hello World!</h1>
//             //     <h1 className="abc">Hello World Again!</h1>
//             // </React.Fragment>

//             // <Fragment>
//             //     <h1 className="abc">Hello World!</h1>
//             //     <h1 className="abc">Hello World Again!</h1>
//             // </Fragment>

//             <>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </>
//         );
//     }
// }

// export default HelloComponent;

// -----------------------------------------------------
// import React from 'react';

// function HelloComponent() {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Fn Declaration Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = function () {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Fn Expression Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = () => {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Arrow Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = () => (
//     <>
//         <h1 className="abc">Hello World! - Using Single Line Arrow Syntax</h1>
//         <h1 className="abc">Hello World Again!</h1>
//     </>
// );

// export default HelloComponent;

// Class Syntax - Stateful Components / Container Component
// Function Syntax - Stateless Components / Presentational Components

import React, { Component } from 'react';

class HelloComponent extends Component {
    render() {
        return (
            <div className="container">
                <h1 className="text-info">Hello World!</h1>
            </div>
        );
    }
}

export default HelloComponent;