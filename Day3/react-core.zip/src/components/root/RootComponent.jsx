/* eslint-disable */
import React, { Component } from 'react';

import CalculatorAssignment from '../assignment/CalculatorAssignment';
import CommunicationRoot from '../assignment/Communication';
import CounterAssignment from '../assignment/CounterAssignment';

import PropTypesDemo from '../1_prop-types/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ParentComponent from '../2_lifecycle-demo/DemoComponent';
import ListRoot from '../3_list-component/ListComponent';
import AjaxComponent from '../4_ajax/AjaxComponent';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CalculatorAssignment /> */}
                    {/* <CounterAssignment /> */}
                    {/* <CommunicationRoot /> */}
                    {/* <PropTypesDemo /> */}
                    {/* <ParentComponent /> */}
                    {/* <ListRoot /> */}
                    <AjaxComponent />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;