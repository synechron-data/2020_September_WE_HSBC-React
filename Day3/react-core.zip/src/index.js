import React from 'react';
import ReactDOM from 'react-dom';

import 'bootstrap/scss/bootstrap.scss';
import './index.css';
import 'bootstrap';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById('root'));