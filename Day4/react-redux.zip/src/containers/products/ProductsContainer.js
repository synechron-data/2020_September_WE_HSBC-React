import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';

import ProductListComponent from '../../components/products/ProductListComponent';
import LoaderAnimation from '../../components/common/LoaderAnimation';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    constructor(props) {
        super(props);
        // this.load = this.load.bind(this);
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    render() {
        return (
            <React.Fragment>
                {/* <button className="btn btn-primary" onClick={this.load}>Load Products</button> */}
                {/* <button className="btn btn-primary" onClick={(e) => this.props.loadProducts()}>Load Products</button> */}
                {
                    this.props.flag ?
                        <React.Fragment>
                            <AddProductButton />
                            <br />
                            <br />
                            <ProductListComponent products={this.props.products} onDelete={this.deleteProduct}/>
                        </React.Fragment>
                        :
                        <div className="pt-5">
                            {
                                this.props.status ? <h2 className="text-warning text-center">{this.props.status}</h2> : null
                            }
                            <LoaderAnimation />
                        </div>
                }
            </React.Fragment>
        );
    }

    deleteProduct(p, e) {
        this.props.deleteProduct(p);
    }

    // load() {
    //     this.props.loadProducts();
    // }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products,
        status: state.productReducer.status,
        flag: state.productReducer.flag
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); },
        deleteProduct: (p) => { dispatch(productActions.deleteProduct(p)); }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);