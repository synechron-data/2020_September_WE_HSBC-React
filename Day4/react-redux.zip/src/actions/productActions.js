import * as actionTypes from './actionTypes';
import productsAPIClient from '../services/products.service';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { message: msg, flag: false }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { data: products, message: msg, flag: true }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { message: msg, flag: true }
    };
}

export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Products Requested Started...."));

        productsAPIClient.getAllProducts().then((products) => {
            // setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Products Request Completed Successfully...."));
            // }, 5000);
        }, (eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

// ------------------------------------------------------ Insert Product

function insertProductSuccess(product, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedProduct) => {
            dispatch(insertProductSuccess(insertedProduct, "Product Created Successfully...."));
            history.push('/products');
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

// ------------------------------------------------------ Update Product

function updateProductSuccess(product, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedProduct) => {
            dispatch(updateProductSuccess(updatedProduct, "Product Updated Successfully...."));
            history.push('/products');
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}

// ------------------------------------------------------ Delete Product

function deleteProductSuccess(product, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductSuccess(product, "Product Deleted Successfully...."));
        }, (eMsg) => {
            console.log(eMsg);
        });
    }
}