import React from 'react';

const ShowCounter = (props) => {
    return (
        <div>
            <div className="row">
                <h1 className="text-info">Show Counter Component</h1>
            </div>
            <div className="row">
                <div className="col-4">
                    <h2 className="text-info">Count: {props.count}</h2>
                </div>
            </div>
        </div>
    );
};

export default ShowCounter;