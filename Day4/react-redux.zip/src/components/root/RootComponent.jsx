/* eslint-disable */
import React, { Component } from 'react';
import NavigationComponent from '../bs-nav/NavigationComponent';

import ErrorHandler from '../common/ErrorHandler';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    <NavigationComponent />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;